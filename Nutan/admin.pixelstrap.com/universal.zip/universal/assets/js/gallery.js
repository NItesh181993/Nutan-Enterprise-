"use strict";
var gallery_main = {
	init: function() {
		(document.getElementById('aniimated-thumbnials'), {
				thumbnail:true
		}),	(document.getElementById('aniimated-thumbnials-2'), {
				thumbnail:true
		}),	(document.getElementById('aniimated-thumbnials-3'), {
				thumbnail:true
		});
	}
};
jQuery(document).ready(function() {
    gallery_main.init();
});