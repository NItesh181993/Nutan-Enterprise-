"use strict";
var gallery_hover = {
    init: function() {
        (document.getElementById('aniimated-thumbnials'), {
            thumbnail:true
        }), (document.getElementById('aniimated-thumbnials1'), {
                thumbnail:true
        }), (document.getElementById('aniimated-thumbnials2'), {
                thumbnail:true
        }), (document.getElementById('aniimated-thumbnials3'), {
                thumbnail:true
        }), (document.getElementById('aniimated-thumbnials4'), {
                thumbnail:true
        }), (document.getElementById('aniimated-thumbnials5'), {
                thumbnail:true
        }), (document.getElementById('aniimated-thumbnials6'), {
                thumbnail:true
        }), (document.getElementById('aniimated-thumbnials7'), {
                thumbnail:true
        }), (document.getElementById('aniimated-thumbnials8'), {
                thumbnail:true
        }), (document.getElementById('aniimated-thumbnials9'), {
                thumbnail:true
        }), (document.getElementById('aniimated-thumbnials10'), {
                thumbnail:true
        }), (document.getElementById('aniimated-thumbnials11'), {
                thumbnail:true
        }), (document.getElementById('aniimated-thumbnials12'), {
                thumbnail:true
        }), (document.getElementById('aniimated-thumbnials13'), {
                thumbnail:true
        }), (document.getElementById('aniimated-thumbnials14'), {
                thumbnail:true
        }), (document.getElementById('aniimated-thumbnials15'), {
                thumbnail:true
        })
    }
};
jQuery(document).ready(function() {
    gallery_hover.init();
});