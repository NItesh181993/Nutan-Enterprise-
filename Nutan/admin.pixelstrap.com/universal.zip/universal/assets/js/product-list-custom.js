"use strict";
$(document).ready(function() {
$('#basic-1').DataTable();
});